### Hexlet tests and linter status:
[![Actions Status](https://github.com/thrtth/python-project-lvl1/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/thrtth/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b07e015385036637a140/maintainability)](https://codeclimate.com/github/thrtth/python-project-lvl1/maintainability)

https://asciinema.org/a/2BVzB6FKA9eeaBB7YrfUJj41u