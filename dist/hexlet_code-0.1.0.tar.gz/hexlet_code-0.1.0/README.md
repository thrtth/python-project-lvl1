### Hexlet tests and linter status:
[![Actions Status](https://github.com/thrtth/python-project-lvl1/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/thrtth/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b07e015385036637a140/maintainability)](https://codeclimate.com/github/thrtth/python-project-lvl1/maintainability)

## Brain games

Brain even - Ответить четное число или нет  
Brain calc - Дать ответ на арифметическую операцию  
Brain gcd - Найти наибольший общий делитель  
Brain progression - Найти пропущенный элемент в арифметической прогрессии  
Brain prime - Определить простое число или нет  


### Asciinema records:

brain-even https://asciinema.org/a/2BVzB6FKA9eeaBB7YrfUJj41u  
brain-calc https://asciinema.org/a/aw3VJiIhQitDkcAyrcHXBZL1J  
brain-gcd https://asciinema.org/a/olztJ80a9ewRF6Bj67oW6MR24  
brain-progression https://asciinema.org/a/EGJgFo8rHvLmrEIJzC4NXLr17  
brain-prime https://asciinema.org/a/B4S5ZRrXjfEhiKptKcUxlrhQ4  
